<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Http\Requests\StoreProductRequest;
use App\Http\Requests\UpdateProductRequest;

class ProductsController extends Controller
{
       /**
     * afisează toate produsele
     * 
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $products = Product::latest()->paginate(10);
        return view('products.index', compact('products'));
    }
    /**
     * Afisare form pt creare produs
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('products.create');
    }
    /**
     * Memorare produs creat acum
     *
     * @param Product $product
     * @param StoreProductRequest $request
     *
     * @return \Illuminate\Http\Response
     */
    public function store(Product $product, StoreProductRequest $request)
    {
        //Numai în scopuri demonstrative. La crearea unui utilizator sau la invitarea unui utilizator
        // ar trebui să creați o parolă aleatorie generată și să o trimiteți prin e-mail utilizatorului
        $product->create(array_merge($request->validated(), ['password' => 'test']));
        return redirect()->route('products.index')->withSuccess(__('Product created successfully.'));
    }
    /**
     * Afisare date produs
     *
     * @param Product $product
     *
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
        return view('products.show', ['product' => $product]);
    }
    /**
    * Creare date produs
    *
    * @param Product $product
    *
    * @return \Illuminate\Http\Response
    */
    public function edit(Product $product)
    {
        return view('products.edit', ['product' => $product]);
    }
    /**
    * Update date produs
    *
    * @param Product $product
    * @param UpdateProductRequest $request
    *
    * @return \Illuminate\Http\Response
    */
    public function update(Product $product, UpdateProductRequest $request)
    {
        $product->update($request->validated());
        return redirect()->route('products.index')->withSuccess(__('Product updated successfully.'));
    }
    /**
    * Stergere date produs
    *
    * @param Product $product
    *
    * @return \Illuminate\Http\Response
    */
    public function destroy(Product $product)
    {
        $product->delete();
        return redirect()->route('products.index')->withSuccess(__('Product deleted successfully.'));
    }
}
